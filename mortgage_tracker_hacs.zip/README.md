Mortgage Tracker - HACS-friendly custom integration
==================================================

What it is
----------
A simple Home Assistant custom integration (HACS-friendly) that tracks a mortgage/loan,
exposes sensors for balance, payments remaining, end date and monthly payment, and offers services to:
  - mortgage_tracker.add_extra_payment
  - mortgage_tracker.set_interest_rate

Install
-------
1. Copy the `custom_components/mortgage_tracker` folder into `<config>/custom_components/` (or add as a custom repo in HACS).
2. Restart Home Assistant.
3. Configure via `configuration.yaml` (example included) or create the integration manually.

Files included
--------------
- custom_components/mortgage_tracker/__init__.py
- custom_components/mortgage_tracker/manifest.json
- custom_components/mortgage_tracker/sensor.py
- custom_components/mortgage_tracker/const.py
- custom_components/mortgage_tracker/services.py
- examples/lovelace-card.yaml
- www/community/mortgage-tracker-card.js  (simple Lovelace card using Chart.js CDN)

Notes
-----
- This is an example starter integration and card. It focuses on functionality and clarity rather than production hardening.
- The frontend card uses Chart.js from a CDN. You can change this to a local copy if preferred.
