/* A tiny Lovelace custom card (very simple) that fetches the mortgage sensor attributes
 * and draws a line chart of remaining balance over time using Chart.js CDN.
 * Drop this file into /www/community/ and add a Resource pointing to /local/community/mortgage-tracker-card.js
 *
 * This is intentionally small and educational; for production you'd use LitElement and better styling.
 */
class MortgageTrackerCard extends HTMLElement {
  setConfig(config) {
    this.config = config;
    if (!config.entity_balance) {
      throw new Error('Please define entity_balance in card config');
    }
  }

  connectedCallback() {
    this.innerHTML = `
      <div style="font-family:Arial, Helvetica, sans-serif; padding:10px; border-radius:8px; box-shadow: 0 1px 3px rgba(0,0,0,0.2);">
        <h3>Mortgage Tracker</h3>
        <div id="summary"></div>
        <canvas id="mortgageChart" width="600" height="200"></canvas>
        <div style="margin-top:8px;">
          <button id="extraPaymentBtn">Add extra £100</button>
          <button id="changeRateBtn">Set rate +0.25%</button>
        </div>
      </div>
    `;
    // lazy load Chart.js from CDN
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/chart.js';
    s.onload = () => this._initCard();
    document.head.appendChild(s);
  }

  async _initCard(){
    const hass = (this.closest('home-assistant') || document).hass;
    await this._render(hass);
    // hook buttons
    this.querySelector('#extraPaymentBtn').addEventListener('click', ()=>{
      // call service to add extra payment of 100 on today's date
      const today = new Date().toISOString().slice(0,10);
      this._callService('add_extra_payment', {amount:100, date: today});
    });
    this.querySelector('#changeRateBtn').addEventListener('click', ()=>{
      // naive: increase current rate by 0.25% via service
      this._callService('set_interest_rate', {annual_interest_rate: 0.25});
    });
    // listen for hass state changes
    window.addEventListener('state_changed', ()=> this._render(window.hass));
  }

  async _callService(service, data){
    const hass = (this.closest('home-assistant') || document).hass;
    // the service namespace is mortgage_tracker
    hass.callService('mortgage_tracker', service, data);
    // re-render after short delay to allow recompute
    setTimeout(()=> this._render(hass), 900);
  }

  async _render(hass){
    const balanceEntity = hass.states[this.config.entity_balance || 'sensor.mortgage_balance'];
    const paymentsEntity = hass.states[this.config.entity_payments_remaining || 'sensor.mortgage_payments_remaining'];
    const monthlyEntity = hass.states[this.config.entity_monthly_payment || 'sensor.mortgage_monthly_payment'];
    const endDateEntity = hass.states[this.config.entity_end_date || 'sensor.mortgage_end_date'];
    const summaryEl = this.querySelector('#summary');
    if(!balanceEntity){ summaryEl.innerHTML='No mortgage sensor found.'; return; }
    const schedule = (balanceEntity.attributes && balanceEntity.attributes.amortization_schedule) || [];
    summaryEl.innerHTML = `
      <div>Balance: <b>${balanceEntity.state}</b></div>
      <div>Monthly payment: <b>${monthlyEntity ? monthlyEntity.state : 'N/A'}</b></div>
      <div>Payments remaining: <b>${paymentsEntity ? paymentsEntity.state : 'N/A'}</b></div>
      <div>End date: <b>${endDateEntity ? endDateEntity.state : 'N/A'}</b></div>
    `;
    // prepare chart data
    const labels = schedule.map(s=> s.date);
    const data = schedule.map(s=> s.remaining_balance);
    // draw
    const ctx = this.querySelector('#mortgageChart').getContext('2d');
    if(this._chart) this._chart.destroy();
    this._chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Remaining balance',
          data: data,
          fill: false,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false
      }
    });
  }
}
customElements.define('mortgage-tracker-card', MortgageTrackerCard);
