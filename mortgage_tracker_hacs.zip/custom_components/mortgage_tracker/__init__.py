"""Mortgage Tracker integration - minimal example"""
from __future__ import annotations
import logging
import asyncio
from datetime import date, datetime
import voluptuous as vol

from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.helpers import entity_platform
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import DOMAIN, ATTR_SCHEDULE

_LOGGER = logging.getLogger(__name__)

DEFAULT_CONFIG = {
    "name": "Mortgage",
    "principal": 300000.0,
    "annual_interest_rate": 3.25,
    "term_years": 30,
    "start_date": date.today().isoformat(),
}

async def async_setup(hass: HomeAssistant, config: dict):
    """Set up the integration from YAML (optional)."""
    conf = config.get(DOMAIN, DEFAULT_CONFIG)
    hass.data.setdefault(DOMAIN, {})

    # store config in hass.data and create a coordinator area
    hass.data[DOMAIN]["config"] = conf

    # Create a simple coordinator to carry the computed schedule and values
    async def _async_update_data():
        # compute schedule
        from .services import compute_amortization_schedule
        schedule = compute_amortization_schedule(
            principal=float(conf.get("principal", DEFAULT_CONFIG["principal"])),
            annual_interest_rate=float(conf.get("annual_interest_rate", DEFAULT_CONFIG["annual_interest_rate"])),
            term_years=int(conf.get("term_years", DEFAULT_CONFIG["term_years"])),
            start_date=conf.get("start_date", DEFAULT_CONFIG["start_date"]))

        return schedule

    coordinator = DataUpdateCoordinator(
        hass,
        _LOGGER,
        name="mortgage_tracker_coordinator",
        update_method=_async_update_data,
        update_interval=None,
    )

    # do initial refresh
    await coordinator.async_refresh()
    hass.data[DOMAIN]["coordinator"] = coordinator

    # register services
    platform = entity_platform.async_get_current_platform()
    # services will be registered via services.py
    from . import services
    services.setup_services(hass)

    # forward setup for sensor platform
    hass.async_create_task(
        hass.helpers.discovery.async_load_platform('sensor', DOMAIN, {}, config)
    )
    return True

async def async_unload_entry(hass: HomeAssistant):
    # not implemented for this example
    return True
