"""Services and amortization logic for Mortgage Tracker"""
from __future__ import annotations
from datetime import datetime, date, timedelta
from typing import List, Dict
import math

from homeassistant.core import HomeAssistant

from .const import DOMAIN, ATTR_SCHEDULE

def setup_services(hass: HomeAssistant) -> None:
    """Register two simple services: add_extra_payment, set_interest_rate"""
    def add_extra(call):
        data = call.data
        amount = float(data.get('amount', 0))
        date_str = data.get('date')  # optional YYYY-MM-DD
        extra = {'amount': amount, 'date': date_str or date.today().isoformat()}
        hass.data.setdefault(DOMAIN, {}).setdefault('extra_payments', []).append(extra)
        # recompute schedule immediately
        _recompute(hass)

    def set_rate(call):
        rate = float(call.data.get('annual_interest_rate'))
        hass.data.setdefault(DOMAIN, {})['config']['annual_interest_rate'] = rate
        _recompute(hass)

    hass.services.register(DOMAIN, 'add_extra_payment', add_extra)
    hass.services.register(DOMAIN, 'set_interest_rate', set_rate)

def _recompute(hass: HomeAssistant):
    """Recompute amortization schedule and store on coordinator data."""
    conf = hass.data[DOMAIN]['config']
    extra = hass.data[DOMAIN].get('extra_payments', [])
    schedule = compute_amortization_schedule(
        principal=float(conf.get('principal', 0)),
        annual_interest_rate=float(conf.get('annual_interest_rate', 0)),
        term_years=int(conf.get('term_years', 0)),
        start_date=conf.get('start_date'),
        extra_payments=extra
    )
    coord = hass.data[DOMAIN]['coordinator']
    # patch coordinator data (coordinator isn't private here in this simple example)
    coord.data = schedule

def compute_amortization_schedule(principal: float, annual_interest_rate: float, term_years: int, start_date: str, extra_payments: List[Dict]=None):
    """Return an amortization schedule as a list of monthly dicts."""
    if extra_payments is None:
        extra_payments = []
    # normalize date
    if isinstance(start_date, str):
        start = datetime.fromisoformat(start_date).date()
    elif isinstance(start_date, date):
        start = start_date
    else:
        start = date.today()

    monthly_rate = (annual_interest_rate / 100) / 12.0 if annual_interest_rate else 0.0
    n_months = term_years * 12
    if monthly_rate == 0:
        monthly_payment = principal / n_months if n_months else principal
    else:
        monthly_payment = principal * (monthly_rate * (1 + monthly_rate) ** n_months) / ((1 + monthly_rate) ** n_months - 1)

    balance = principal
    schedule = []
    month = 0
    # convert extra payments to dict by date (YYYY-MM-DD)
    extras_by_date = {}
    for e in extra_payments:
        d = e.get('date', start.isoformat())
        extras_by_date.setdefault(d, 0.0)
        extras_by_date[d] += float(e.get('amount', 0.0))

    while balance > 0.01 and month < 1000:  # safety cap
        month += 1
        pay_date = (start + timedelta(days=30*month)).replace(day=1) if True else start
        interest = balance * monthly_rate
        principal_paid = monthly_payment - interest
        if principal_paid > balance:
            principal_paid = balance
        extra = extras_by_date.get(pay_date.isoformat(), 0.0)
        total_principal = principal_paid + extra
        balance = max(0.0, balance - total_principal)
        schedule.append({
            'month': month,
            'date': pay_date.isoformat(),
            'payment': round(monthly_payment + extra, 2),
            'interest': round(interest, 2),
            'principal_paid': round(total_principal, 2),
            'remaining_balance': round(balance, 2)
        })
        if month > n_months and balance>0:
            # if still remaining after normal term, continue but warn
            pass
        # safety exit
        if month > n_months*2:
            break

    # add summary
    summary = {
        'monthly_payment': round(monthly_payment,2),
        'payments_count': len(schedule),
        'end_date': schedule[-1]['date'] if schedule else start.isoformat(),
        'schedule': schedule
    }
    return summary
