DOMAIN = "mortgage_tracker"
DEFAULT_NAME = "Mortgage Tracker"
ATTR_SCHEDULE = "amortization_schedule"
