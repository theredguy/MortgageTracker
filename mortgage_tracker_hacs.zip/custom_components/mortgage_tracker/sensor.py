"""Sensors for the Mortgage Tracker integration"""
from __future__ import annotations
from homeassistant.helpers.entity import Entity
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN, ATTR_SCHEDULE

async def async_setup_platform(hass: HomeAssistant, config, async_add_entities: AddEntitiesCallback, discovery_info=None):
    """Set up sensors."""
    coordinator = hass.data[DOMAIN]['coordinator']
    async_add_entities([
        MortgageBalanceSensor(hass, coordinator),
        MortgagePaymentsRemainingSensor(hass, coordinator),
        MortgageEndDateSensor(hass, coordinator),
        MortgageMonthlyPaymentSensor(hass, coordinator),
    ])

class BaseMortgageSensor(Entity):
    def __init__(self, hass: HomeAssistant, coordinator):
        self.hass = hass
        self.coordinator = coordinator
        self._state = None

    @property
    def available(self):
        return self.coordinator and self.coordinator.data is not None

    async def async_update(self):
        # use coordinator data directly
        self._data = self.coordinator.data

class MortgageBalanceSensor(BaseMortgageSensor):
    @property
    def name(self):
        return "Mortgage Balance"

    @property
    def unique_id(self):
        return "mortgage_tracker_balance"

    @property
    def state(self):
        return self.coordinator.data.get('schedule')[-1]['remaining_balance'] if self.coordinator.data else None

    @property
    def extra_state_attributes(self):
        return {
            ATTR_SCHEDULE: self.coordinator.data.get('schedule') if self.coordinator.data else []
        }

class MortgagePaymentsRemainingSensor(BaseMortgageSensor):
    @property
    def name(self):
        return "Mortgage Payments Remaining"

    @property
    def unique_id(self):
        return "mortgage_tracker_payments_remaining"

    @property
    def state(self):
        return self.coordinator.data.get('payments_count') if self.coordinator.data else None

class MortgageEndDateSensor(BaseMortgageSensor):
    @property
    def name(self):
        return "Mortgage End Date"

    @property
    def unique_id(self):
        return "mortgage_tracker_end_date"

    @property
    def state(self):
        return self.coordinator.data.get('end_date') if self.coordinator.data else None

class MortgageMonthlyPaymentSensor(BaseMortgageSensor):
    @property
    def name(self):
        return "Mortgage Monthly Payment"

    @property
    def unique_id(self):
        return "mortgage_tracker_monthly_payment"

    @property
    def state(self):
        return self.coordinator.data.get('monthly_payment') if self.coordinator.data else None
